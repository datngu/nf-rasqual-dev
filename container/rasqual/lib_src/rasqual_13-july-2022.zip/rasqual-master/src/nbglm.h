double olm(double* y, double* X, double* ki, double* w, long N0, long P, double* beta, double* work);
double nbglm(double* y, double* X, double* ki, double* dki, double* w, long N0, long P, double* beta, double* ptheta, int fixTheta, double* work);
